<?php

namespace App\SupportedApps\Sympa;

class Sympa extends \App\SupportedApps
{
}
