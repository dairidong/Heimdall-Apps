<ul class="livestats">
    <li>
        <span class="title">Pending</span>
        <strong>{!! $pending !!}</strong>
    </li>
    <li>
        <span class="title">Processing</span>
        <strong>{!! $processing !!}</strong>
    </li>
</ul>
