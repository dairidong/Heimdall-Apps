<?php

namespace App\SupportedApps\Snapdrop;

class Snapdrop extends \App\SupportedApps
{
}
