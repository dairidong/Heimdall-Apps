<?php

namespace App\SupportedApps\KastenbyVeeam;

class KastenbyVeeam extends \App\SupportedApps
{
}
