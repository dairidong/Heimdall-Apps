<?php

namespace App\SupportedApps\Droppy;

class Droppy extends \App\SupportedApps
{
}
