<?php

namespace App\SupportedApps\Funkwhale;

class Funkwhale extends \App\SupportedApps
{
}
