<?php

namespace App\SupportedApps\ShellinaBox;

class ShellinaBox extends \App\SupportedApps
{
}
