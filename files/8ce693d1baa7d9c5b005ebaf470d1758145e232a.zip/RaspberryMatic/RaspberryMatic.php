<?php

namespace App\SupportedApps\RaspberryMatic;

class RaspberryMatic extends \App\SupportedApps
{
}
