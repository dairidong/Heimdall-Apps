<?php

namespace App\SupportedApps\BarcodeBuddy;

class BarcodeBuddy extends \App\SupportedApps
{
}
