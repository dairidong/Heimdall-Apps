<ul class="livestats">
    <li>
        <span class="title">Contacts</span>
        <strong>{!! $contacts !!}</strong>
    </li>
</ul>
