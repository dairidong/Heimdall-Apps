<?php

namespace App\SupportedApps\JoplinServer;

class JoplinServer extends \App\SupportedApps
{
}
