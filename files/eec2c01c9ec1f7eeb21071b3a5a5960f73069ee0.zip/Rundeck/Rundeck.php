<?php

namespace App\SupportedApps\Rundeck;

class Rundeck extends \App\SupportedApps
{
}
