<?php

namespace App\SupportedApps\ProjectSend;

class ProjectSend extends \App\SupportedApps
{
}
