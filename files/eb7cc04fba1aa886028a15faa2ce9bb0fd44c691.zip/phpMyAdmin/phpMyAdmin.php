<?php

namespace App\SupportedApps\phpMyAdmin;

class phpMyAdmin extends \App\SupportedApps // phpcs:ignore
{
}
