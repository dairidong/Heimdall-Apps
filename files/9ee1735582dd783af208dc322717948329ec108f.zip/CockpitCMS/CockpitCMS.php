<?php

namespace App\SupportedApps\CockpitCMS;

class CockpitCMS extends \App\SupportedApps
{
}
