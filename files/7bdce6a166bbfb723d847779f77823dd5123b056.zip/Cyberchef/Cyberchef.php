<?php

namespace App\SupportedApps\Cyberchef;

class Cyberchef extends \App\SupportedApps
{
}
