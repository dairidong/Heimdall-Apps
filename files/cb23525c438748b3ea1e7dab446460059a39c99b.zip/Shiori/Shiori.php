<?php

namespace App\SupportedApps\Shiori;

class Shiori extends \App\SupportedApps
{
}
